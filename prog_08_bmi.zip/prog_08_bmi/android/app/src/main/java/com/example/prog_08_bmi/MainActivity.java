package com.example.prog_08_bmi;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
